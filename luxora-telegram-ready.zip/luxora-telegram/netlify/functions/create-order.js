exports.handler = async (event) => {
  if (event.httpMethod !== 'POST') {
    return { statusCode: 405, headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ ok: false, error: 'Method not allowed' }) };
  }
  const token = process.env.TELEGRAM_BOT_TOKEN;
  const chatId = process.env.TELEGRAM_CHAT_ID;
  if (!token || !chatId) {
    return { statusCode: 500, headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ ok: false, error: 'Telegram sozlamalari topilmadi' }) };
  }
  try {
    const data = JSON.parse(event.body || '{}');
    const clean = (v, max = 500) => String(v || '').trim().slice(0, max);
    const name = clean(data.name, 120);
    const phone = clean(data.phone, 60);
    const address = clean(data.address, 500);
    const items = Array.isArray(data.items) ? data.items.slice(0, 30) : [];
    if (!name || !phone || !address || !items.length) {
      return { statusCode: 400, headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ ok: false, error: 'Buyurtma ma’lumotlari to‘liq emas' }) };
    }
    const money = n => new Intl.NumberFormat('uz-UZ').format(Number(n) || 0) + ' so‘m';
    const lines = items.map((x, i) => `${i + 1}. ${clean(x.name, 100)} — ${Math.max(1, Math.min(99, Number(x.qty) || 1))} dona × ${money(x.price)}`);
    const total = items.reduce((sum, x) => sum + (Number(x.price) || 0) * Math.max(1, Math.min(99, Number(x.qty) || 1)), 0);
    const message = [
      '🛍️ LUXORA — YANGI BUYURTMA',
      '',
      `👤 Mijoz: ${name}`,
      `📞 Telefon: ${phone}`,
      `📍 Manzil: ${address}`,
      '',
      '📦 Mahsulotlar:',
      ...lines,
      '',
      `💰 Jami: ${money(total)}`,
      `🕒 Vaqt: ${new Date().toLocaleString('uz-UZ', { timeZone: 'Asia/Tashkent' })}`
    ].join('\n');
    const response = await fetch(`https://api.telegram.org/bot${token}/sendMessage`, {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ chat_id: chatId, text: message })
    });
    const result = await response.json();
    if (!response.ok || !result.ok) {
      return { statusCode: 502, headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ ok: false, error: 'Telegram xabarni qabul qilmadi' }) };
    }
    return { statusCode: 200, headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ ok: true }) };
  } catch (error) {
    return { statusCode: 400, headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ ok: false, error: 'Noto‘g‘ri so‘rov' }) };
  }
};
